
package modell;


public class administrador {
    
}
