
package modell;

/**
 *
 * @author ASUS
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class ConexionDB {
    private static Connection conn;
   private static final String driver="com.mysql.cj.jdbc.Driver";
   
      /* metodo para conectar a la base de datos*/
 public ConexionDB(){
   conn = null;
 
  try{
     Class.forName(driver);
     conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/asesor_tareas","root","");
     if(conn != null){
         System.out.println("Conexion Establecida..");
     }
     
   } catch (ClassNotFoundException | SQLException e){
       System.out.println("Error al conectar"+e);
   }
 }
 /*Metodo que retorna la coneccion*/
 public Connection getConnection(){
  return conn;
}
  /*Metodo para desconectarnos de la base de datos*/
public void desconectar(){
  conn = null;
  if(conn==null){
      System.out.println("Conexion Terminada");
  }
}
}
