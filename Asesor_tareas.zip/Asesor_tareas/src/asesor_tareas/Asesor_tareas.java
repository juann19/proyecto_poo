
package asesor_tareas;

import modell.*;
import controller.*;
import view.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class Asesor_tareas {

  
    public static void main(String[] args) {
         
        Principal obj=new Principal();
        
        obj.setVisible(true);
                
                
        
    }
     
    }
    

