package modell;
    import java.sql.Connection;
    import java.sql.PreparedStatement;
    import java.sql.ResultSet;
    import java.sql.SQLException;
    import java.util.ArrayList;
    import java.util.List;

public class Usuario_Dao extends DAO<usuario> {

    public Usuario_Dao(Connection conn) {
        super(conn);
    }
    @Override
    public List<usuario> getAll() throws SQLException {
    
        List<usuario> usuarios=new ArrayList<>();
        String sql="SELECT * FROM Usuario";
        PreparedStatement stmt= conn.prepareStatement(sql);
        ResultSet rs= stmt.executeQuery();
        while(rs.next()){
            usuario usu= new usuario();
            usu.setId(rs.getInt("Id_usuario"));
            usu.setNombre(rs.getString("Nombre"));
            usu.setCorreo(rs.getString("Correo"));
            usu.setContraseña(rs.getString("Contraseña"));
            usu.setUsuario(rs.getString("usuario"));  
        }
         return usuarios;
    }
    @Override
    public usuario get(int id) throws SQLException {
        
        usuario usuario=null;
        String sql="SELECT * FROM usuario WHERE Id_usuario= ?";
         PreparedStatement stmt= conn.prepareStatement(sql);
         stmt.setInt(1, id);
         ResultSet rs= stmt.executeQuery();
         if(rs.next()){
             usuario usu1=new usuario();
             usu1.setId(rs.getInt("usuario_id"));
             usu1.setNombre(rs.getString("nombre"));
             usu1.setCorreo(rs.getString("correo"));
             usu1.setContraseña(rs.getString("contraseña"));
             usu1.setUsuario(rs.getString("usuario"));
         }
         return usuario;
    }
    @Override
    public void save(usuario usuario) throws SQLException {
        String sql="INSERT INTO usuario (nombre,correo,contraseña,usuario) VALUES (?,?,?,?)";
        PreparedStatement stmt= conn.prepareStatement(sql);
        stmt.setString(1, usuario.getNombre());
        stmt.setString(2, usuario.getCorreo());
        stmt.setString(3, usuario.getContraseña());
        stmt.setString(4, usuario.getUsuario());
        stmt.executeUpdate();
    }
    @Override
    public void update(usuario usuario) throws SQLException {
        String sql="UPDATE usuario SET Nombre= ?, Correo= ?, Contraseña= ?, usuario= ? WHERE Id_usuario=?";
        PreparedStatement stmt=conn.prepareStatement(sql);
        stmt.setString(1, usuario.getNombre());
        stmt.setString(2, usuario.getCorreo());
        stmt.setString(3, usuario.getContraseña());
        stmt.setString(4, usuario.getUsuario());
        stmt.setInt(5, usuario.getId());
        stmt.executeUpdate();
    }
    @Override
    public void delete(int id) throws SQLException {
        String sql="DELETE FROM usuario WHERE Id_usuario= ?";
        PreparedStatement stmt=conn.prepareStatement(sql);
        stmt.setInt(1, id);
        stmt.executeUpdate();   
    }
}
